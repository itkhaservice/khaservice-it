\# KHASERVICE-IT



Phần mềm quản lý thiết bị IT nội bộ cho công ty KHASERVICE.



\## Công nghệ

\- PHP thuần

\- MySQL

\- XAMPP

\- phpMyAdmin



\## Cài đặt

1\. Clone repo

2\. Import `schema.sql`

3\. Copy `config/db.example.php` → `config/db.php`

4\. Cấu hình database

5\. Truy cập `http://localhost/khaservice-it/public`



\## Lưu ý

\- Không push file cấu hình DB

\- Không push dữ liệu thật

\- Thư mục uploads chỉ dùng local

