<?php
// Tự động chuyển hướng vào thư mục public
header("Location: public/index.php");
exit;
?>
