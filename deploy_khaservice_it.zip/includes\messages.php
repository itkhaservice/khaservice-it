<?php
// Function to set a session message
function set_message($type, $message) {
    if (!isset($_SESSION['messages'])) {
        $_SESSION['messages'] = [];
    }
    $_SESSION['messages'][] = ['type' => $type, 'content' => $message];
}

// Function to display and clear session messages
function display_messages() {
    if (isset($_SESSION['messages']) && !empty($_SESSION['messages'])) {
        echo '<div id="message-container" class="message-container">'; // Thêm container
        foreach ($_SESSION['messages'] as $message) {
            // Thêm class 'show' để hiển thị ban đầu
            echo '<div class="message-box ' . htmlspecialchars($message['type']) . ' show">';
            echo htmlspecialchars($message['content']);
            echo '</div>';
            echo '<script>window.playAudioFeedback("' . htmlspecialchars($message['type']) . '");</script>';
        }
        echo '</div>'; // Đóng container
        unset($_SESSION['messages']); // Clear messages after displaying
    }
}
?>
