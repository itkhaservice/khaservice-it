<?php
/**
 * Entry point của ứng dụng.
 * Nhúng file index chính từ thư mục public để giữ sạch đường dẫn assets.
 */
require_once __DIR__ . '/public/index.php';
?>
